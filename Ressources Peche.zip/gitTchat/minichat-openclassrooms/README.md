Mini-chat OpenClassrooms
========================

Ce projet correspond à l'activité de la partie 3 du cours « Concevez votre site web avec PHP et MySQL » sur le site [OpenClassrooms](http://openclassrooms.com/).

Il met également en pratique les acquis du cours « Apprenez à créer votre site web avec HTML5 et CSS3 » disponible sur le même site.

Et sert également pour le cours « Git & GitHub »...
